<script setup lang="ts">
  const cartStore = useCartStore();
  // 백엔드 API 를 호출하여 유저정보에 보관하고 있던 cart정보를 초기화 시켜준다.
  cartStore.items = [];
</script>
<template>
  <div class="mt-10 max-w-6xl mx-auto p-5">
    <h1 class="text-3xl">Thank you for your purchase!</h1>
  </div>
</template>
