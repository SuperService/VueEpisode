import products from "@/data/products";
export default defineEventHandler((event) => {
  return products;
});
