globalThis._importMeta_={url:import.meta.url,env:process.env};import 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/node-fetch-native/dist/polyfill.mjs';
import { Server } from 'http';
import { tmpdir } from 'os';
import { join } from 'path';
import { mkdirSync } from 'fs';
import { parentPort, threadId } from 'worker_threads';
import { provider, isWindows } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/std-env/dist/index.mjs';
import { defineEventHandler, handleCacheHeaders, createEvent, createApp, createRouter, lazyEventHandler, useBody, eventHandler, useQuery } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/h3/dist/index.mjs';
import { createFetch as createFetch$1, Headers } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/ohmyfetch/dist/node.mjs';
import destr from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/destr/dist/index.mjs';
import { createRouter as createRouter$1 } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/radix3/dist/index.mjs';
import { createCall, createFetch } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/unenv/runtime/fetch/index.mjs';
import { createHooks } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/hookable/dist/index.mjs';
import { hash } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/ohash/dist/index.mjs';
import { parseURL, withQuery, joinURL } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/ufo/dist/index.mjs';
import { createStorage } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/unstorage/dist/index.mjs';
import _unstorage_drivers_fs from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/unstorage/dist/drivers/fs.mjs';
import Stripe from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/stripe/lib/stripe.js';
import { createRenderer } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/vue-bundle-renderer/dist/index.mjs';
import devalue from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/@nuxt/devalue/dist/devalue.mjs';
import { renderToString } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/vue/server-renderer/index.mjs';
import { snakeCase } from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/node_modules/scule/dist/index.mjs';
import htmlTemplate from 'file://E:/pending_project/vuejs-forge-episode-2-the-project/.nuxt/views/document.template.mjs';

const _runtimeConfig = {"app":{"baseURL":"/","buildAssetsDir":"/_nuxt/","cdnURL":""},"nitro":{"routes":{},"envPrefix":"NUXT_"},"public":{"contentfulSpace":"5xe8h3b9y55t","contentfulPublicAccessToken":"1uuS9K4kK-0PEVF8hiPdW44_5rda7LxZgJVr6dYJZqQ","deskreeBaseUrl":"https://forge2.api.deskree.com/api/v1","altogicEnvUrl":"https://te4g-o2jj.c2-europe.altogic.com","altogicClientKey":"e680a5d5179b4b0fb9611a15d247278f"},"stripeSecret":"sk_test_51LIthZJWhNxJ2tl450T8qolmFohol5vTQCQrBjYOkVtM6z0eCCa2E3OmaPTXPsS6FA5Fz39j3CeWBFP3yGSywLA100FrYZXwWa"};
const ENV_PREFIX = "NITRO_";
const ENV_PREFIX_ALT = _runtimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_";
const getEnv = (key) => {
  const envKey = snakeCase(key).toUpperCase();
  return destr(process.env[ENV_PREFIX + envKey] ?? process.env[ENV_PREFIX_ALT + envKey]);
};
function isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function overrideConfig(obj, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey);
    if (isObject(obj[key])) {
      if (isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
      }
      overrideConfig(obj[key], subKey);
    } else {
      obj[key] = envValue ?? obj[key];
    }
  }
}
overrideConfig(_runtimeConfig);
const config = deepFreeze(_runtimeConfig);
const useRuntimeConfig = () => config;
function deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      deepFreeze(value);
    }
  }
  return Object.freeze(object);
}

const globalTiming = globalThis.__timing__ || {
  start: () => 0,
  end: () => 0,
  metrics: []
};
function timingMiddleware(_req, res, next) {
  const start = globalTiming.start();
  const _end = res.end;
  res.end = (data, encoding, callback) => {
    const metrics = [["Generate", globalTiming.end(start)], ...globalTiming.metrics];
    const serverTiming = metrics.map((m) => `-;dur=${m[1]};desc="${encodeURIComponent(m[0])}"`).join(", ");
    if (!res.headersSent) {
      res.setHeader("Server-Timing", serverTiming);
    }
    _end.call(res, data, encoding, callback);
  };
  next();
}

const serverAssets = [{"baseName":"server","dir":"E:/pending_project/vuejs-forge-episode-2-the-project/server/assets"}];

const assets = createStorage();

for (const asset of serverAssets) {
  assets.mount(asset.baseName, _unstorage_drivers_fs({ base: asset.dir }));
}

const storage = createStorage({});

const useStorage = () => storage;

storage.mount('/assets', assets);

storage.mount('root', _unstorage_drivers_fs({"driver":"fs","base":"E:\\pending_project\\vuejs-forge-episode-2-the-project","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('src', _unstorage_drivers_fs({"driver":"fs","base":"E:\\pending_project\\vuejs-forge-episode-2-the-project\\server","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('build', _unstorage_drivers_fs({"driver":"fs","base":"E:\\pending_project\\vuejs-forge-episode-2-the-project\\.nuxt","ignore":["**/node_modules/**","**/.git/**"]}));
storage.mount('cache', _unstorage_drivers_fs({"driver":"fs","base":"E:\\pending_project\\vuejs-forge-episode-2-the-project\\.nuxt\\cache","ignore":["**/node_modules/**","**/.git/**"]}));

const defaultCacheOptions = {
  name: "_",
  base: "/cache",
  swr: true,
  maxAge: 1
};
function defineCachedFunction(fn, opts) {
  opts = { ...defaultCacheOptions, ...opts };
  const pending = {};
  const group = opts.group || "nitro";
  const name = opts.name || fn.name || "_";
  const integrity = hash([opts.integrity, fn, opts]);
  async function get(key, resolver) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    const entry = await useStorage().getItem(cacheKey) || {};
    const ttl = (opts.maxAge ?? opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl;
    const _resolve = async () => {
      if (!pending[key]) {
        entry.value = void 0;
        entry.integrity = void 0;
        entry.mtime = void 0;
        entry.expires = void 0;
        pending[key] = Promise.resolve(resolver());
      }
      entry.value = await pending[key];
      entry.mtime = Date.now();
      entry.integrity = integrity;
      delete pending[key];
      useStorage().setItem(cacheKey, entry).catch((error) => console.error("[nitro] [cache]", error));
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (opts.swr && entry.value) {
      _resolvePromise.catch(console.error);
      return Promise.resolve(entry);
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const key = (opts.getKey || getKey)(...args);
    const entry = await get(key, () => fn(...args));
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
const cachedFunction = defineCachedFunction;
function getKey(...args) {
  return args.length ? hash(args, {}) : "";
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions) {
  const _opts = {
    ...opts,
    getKey: (event) => {
      const url = event.req.originalUrl || event.req.url;
      const friendlyName = decodeURI(parseURL(url).pathname).replace(/[^a-zA-Z0-9]/g, "").substring(0, 16);
      const urlHash = hash(url);
      return `${friendlyName}.${urlHash}`;
    },
    group: opts.group || "nitro/handlers",
    integrity: [
      opts.integrity,
      handler
    ]
  };
  const _cachedHandler = cachedFunction(async (incomingEvent) => {
    const reqProxy = cloneWithProxy(incomingEvent.req, { headers: {} });
    const resHeaders = {};
    const resProxy = cloneWithProxy(incomingEvent.res, {
      statusCode: 200,
      getHeader(name) {
        return resHeaders[name];
      },
      setHeader(name, value) {
        resHeaders[name] = value;
        return this;
      },
      getHeaderNames() {
        return Object.keys(resHeaders);
      },
      hasHeader(name) {
        return name in resHeaders;
      },
      removeHeader(name) {
        delete resHeaders[name];
      },
      getHeaders() {
        return resHeaders;
      }
    });
    const event = createEvent(reqProxy, resProxy);
    event.context = incomingEvent.context;
    const body = await handler(event);
    const headers = event.res.getHeaders();
    headers.Etag = `W/"${hash(body)}"`;
    headers["Last-Modified"] = new Date().toUTCString();
    const cacheControl = [];
    if (opts.swr) {
      if (opts.maxAge) {
        cacheControl.push(`s-maxage=${opts.maxAge}`);
      }
      if (opts.staleMaxAge) {
        cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
      } else {
        cacheControl.push("stale-while-revalidate");
      }
    } else if (opts.maxAge) {
      cacheControl.push(`max-age=${opts.maxAge}`);
    }
    if (cacheControl.length) {
      headers["Cache-Control"] = cacheControl.join(", ");
    }
    const cacheEntry = {
      code: event.res.statusCode,
      headers,
      body
    };
    return cacheEntry;
  }, _opts);
  return defineEventHandler(async (event) => {
    const response = await _cachedHandler(event);
    if (event.res.headersSent || event.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["Last-Modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.res.statusCode = response.code;
    for (const name in response.headers) {
      event.res.setHeader(name, response.headers[name]);
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

const plugins = [
  
];

function hasReqHeader(req, header, includes) {
  const value = req.headers[header];
  return value && typeof value === "string" && value.toLowerCase().includes(includes);
}
function isJsonRequest(event) {
  return hasReqHeader(event.req, "accept", "application/json") || hasReqHeader(event.req, "user-agent", "curl/") || hasReqHeader(event.req, "user-agent", "httpie/") || event.req.url?.endsWith(".json") || event.req.url?.includes("/api/");
}
function normalizeError(error) {
  const cwd = process.cwd();
  const stack = (error.stack || "").split("\n").splice(1).filter((line) => line.includes("at ")).map((line) => {
    const text = line.replace(cwd + "/", "./").replace("webpack:/", "").replace("file://", "").trim();
    return {
      text,
      internal: line.includes("node_modules") && !line.includes(".cache") || line.includes("internal") || line.includes("new Promise")
    };
  });
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage ?? (statusCode === 404 ? "Route Not Found" : "Internal Server Error");
  const message = error.message || error.toString();
  return {
    stack,
    statusCode,
    statusMessage,
    message
  };
}

const errorHandler = (async function errorhandler(_error, event) {
  const { stack, statusCode, statusMessage, message } = normalizeError(_error);
  const errorObject = {
    url: event.req.url,
    statusCode,
    statusMessage,
    message,
    description: statusCode !== 404 ? `<pre>${stack.map((i) => `<span class="stack${i.internal ? " internal" : ""}">${i.text}</span>`).join("\n")}</pre>` : "",
    data: _error.data
  };
  event.res.statusCode = errorObject.statusCode;
  event.res.statusMessage = errorObject.statusMessage;
  if (errorObject.statusCode !== 404) {
    console.error("[nuxt] [request error]", errorObject.message + "\n" + stack.map((l) => "  " + l.text).join("  \n"));
  }
  if (isJsonRequest(event)) {
    event.res.setHeader("Content-Type", "application/json");
    event.res.end(JSON.stringify(errorObject));
    return;
  }
  const url = withQuery("/__nuxt_error", errorObject);
  const html = await $fetch(url).catch((error) => {
    console.error("[nitro] Error while generating error response", error);
    return errorObject.statusMessage;
  });
  event.res.setHeader("Content-Type", "text/html;charset=UTF-8");
  event.res.end(html);
});

const _lazy_0aGaNs = () => Promise.resolve().then(function () { return products$1; });
const _lazy_oT7OiE = () => Promise.resolve().then(function () { return cart_post$1; });
const _lazy_RTrlgG = () => Promise.resolve().then(function () { return renderer$1; });

const handlers = [
  { route: '/api/products', handler: _lazy_0aGaNs, lazy: true, middleware: false, method: undefined },
  { route: '/api/cart', handler: _lazy_oT7OiE, lazy: true, middleware: false, method: "post" },
  { route: '/__nuxt_error', handler: _lazy_RTrlgG, lazy: true, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_RTrlgG, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const h3App = createApp({
    debug: destr(true),
    onError: errorHandler
  });
  h3App.use(config.app.baseURL, timingMiddleware);
  const router = createRouter();
  const routerOptions = createRouter$1({ routes: config.nitro.routes });
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    const referenceRoute = h.route.replace(/:\w+|\*\*/g, "_");
    const routeOptions = routerOptions.lookup(referenceRoute) || {};
    if (routeOptions.swr) {
      handler = cachedEventHandler(handler, {
        group: "nitro/routes"
      });
    }
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(/\/+/g, "/");
      h3App.use(middlewareBase, handler);
    } else {
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router);
  const localCall = createCall(h3App.nodeHandler);
  const localFetch = createFetch(localCall, globalThis.fetch);
  const $fetch = createFetch$1({ fetch: localFetch, Headers, defaults: { baseURL: config.app.baseURL } });
  globalThis.$fetch = $fetch;
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch
  };
  for (const plugin of plugins) {
    plugin(app);
  }
  return app;
}
const nitroApp = createNitroApp();

const server = new Server(nitroApp.h3App.nodeHandler);
function getAddress() {
  if (provider === "stackblitz" || process.env.NITRO_NO_UNIX_SOCKET) {
    return "0";
  }
  const socketName = `worker-${process.pid}-${threadId}.sock`;
  if (isWindows) {
    return join("\\\\.\\pipe\\nitro", socketName);
  } else {
    const socketDir = join(tmpdir(), "nitro");
    mkdirSync(socketDir, { recursive: true });
    return join(socketDir, socketName);
  }
}
const listenAddress = getAddress();
server.listen(listenAddress, () => {
  const _address = server.address();
  parentPort.postMessage({
    event: "listen",
    address: typeof _address === "string" ? { socketPath: _address } : { host: "localhost", port: _address.port }
  });
});
{
  process.on("unhandledRejection", (err) => console.error("[nitro] [dev] [unhandledRejection]", err));
  process.on("uncaughtException", (err) => console.error("[nitro] [dev] [uncaughtException]", err));
}

const products$2 = [
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "3i0FygW932q7IVP4bivAdL",
			type: "Entry",
			createdAt: "2022-08-09T19:06:50.723Z",
			updatedAt: "2022-08-09T19:06:50.723Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Black Garlic And Carolina Reaper Hot Sauce",
			summary: "By Bravado Spice FEATURED ON HOT ONES Gluten Free, Vegan, Low Carb, Paleo Hot Sauce All Natural 5 oz Hot Sauce Bottle Award Winning Gourmet Hot Sauce ",
			price: 999,
			description: "- Vegan\n- Gluten-free\n- All natural\n- No added sugar\n- Made in Texas\n",
			heatLevel: "Hot",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "34tLG4DpSj18iYjA0MFYPs",
						type: "Asset",
						createdAt: "2022-08-09T19:06:45.335Z",
						updatedAt: "2022-08-09T19:06:45.335Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Black Garlic And Carolina Reaper Hot Sauce ",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/34tLG4DpSj18iYjA0MFYPs/116adf2430995d80b1fe9fe851ab996d/51z9CpKZ9ZL._SX679_.jpeg",
							details: {
								size: 22883,
								image: {
									width: 679,
									height: 679
								}
							},
							fileName: "51z9CpKZ9ZL._SX679_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	},
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "5ijmFfTSEqj0G8h73g3CrI",
			type: "Entry",
			createdAt: "2022-08-09T18:52:56.021Z",
			updatedAt: "2022-08-09T18:52:56.021Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Heartbeat Hot Sauce- Pineapple Habanero",
			summary: "6 oz- Small Batch & Handmade, Vegan, Preservative Free ",
			price: 1195,
			description: "\n- You will receive (1) 6 oz. bottles of Heartbeat Pineapple Habanero Hot Sauce. Featured on Hot Ones, Heartbeat Hot Sauce is all about the peppers. Heartbeat Hot Sauce's sweet and mild addition to the family.\n- Our most recent collaboration with an Ontario craft brewery, this time from our home town of Thunder Bay. Made with the help of Sleeping Giant Brewery*s award winning Beaver Duck session IPA, this sauce has a boldly pronounced fruitiness and a bright but savoury vibe from start to finish.\n- Expect a very approachable balance of heat and flavour, a Heartbeat signature characteristic!\n- This sweet and spicy vegan mix is made with Pineapple, Yellow Bell Pepper, Onion, Ale (Water, Hops, Malted Barley, Yeast) Distilled Vinegar, Habaneros, Lime Juice, Organic Cane Sugar, Kosher Salt, Garlic, and Canola Oil.\n- Enjoy in your favorite guacamole, on pizza, eggs, tacos, white bean soup, in cocktails, on your favorite sandwiches, spice up your marinades! Top off your nachos, spice up your steak and grilled chicken or just throw it back right out of the bottle, it's that good!\n",
			heatLevel: "Mild",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "5vUkOQDUSZAKSwXByyeruQ",
						type: "Asset",
						createdAt: "2022-08-09T18:52:49.638Z",
						updatedAt: "2022-08-09T18:52:49.638Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Heartbeat Hot Sauce- Pineapple Habanero",
						description: "",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/5vUkOQDUSZAKSwXByyeruQ/8d503e499b0a9649a0165b399efbaeca/61N0eH6L6LL._SX679_.jpeg",
							details: {
								size: 15529,
								image: {
									width: 679,
									height: 679
								}
							},
							fileName: "61N0eH6L6LL._SX679_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	},
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "3fnDoSexu2PM2VX4oPa6Tj",
			type: "Entry",
			createdAt: "2022-08-09T18:50:16.463Z",
			updatedAt: "2022-08-09T18:50:16.463Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Tampa Bay Hot Sauce Company",
			summary: "Hot Sauce Menage A Peppers, 5 Fl Oz ",
			price: 1099,
			description: "- Diet Type: Gluten Free\n- Vegan; Made without any animal products, including seafood, dairy, eggs or honey\n",
			heatLevel: "Medium",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "202p5VFQYWmea7DlxE09fc",
						type: "Asset",
						createdAt: "2022-08-09T18:50:09.399Z",
						updatedAt: "2022-08-09T18:50:09.399Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Tampa Bay Hot Sauce Company",
						description: "",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/202p5VFQYWmea7DlxE09fc/42c2f8d621bdb57f45df99639c9f964e/61ZaGnIHY3L._SY879_.jpeg",
							details: {
								size: 33249,
								image: {
									width: 232,
									height: 879
								}
							},
							fileName: "61ZaGnIHY3L._SY879_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	},
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "35sVQjPp20RwkmJLZOl9ou",
			type: "Entry",
			createdAt: "2022-08-09T18:47:26.389Z",
			updatedAt: "2022-08-09T18:47:26.389Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Elijah's Xtreme Regret Hot Sauce",
			summary: "Carolina Reaper and Trinidad Scorpion - The 2 Hottest Peppers in the World for an Extreme Fiery Heat ",
			price: 898,
			description: "- SMOKIN’ HOT Trinidad Scorpion and the WORLD'S HOTTEST Carolina Reaper peppers make up Elijah’s Xtreme - Xtreme Regret Hot Sauce. With SHUs of 800,000 - 1,600,000 respectively, it’s like a molten lava field washing over your taste buds\n- LEGENDARY Scorpion and Carolina Reaper peppers are the first to scientifically test over 1.6 million scovilles. These peppers are so hot that it will bring tears to your eyes, sweat to your head and warm you from the inside out\n- MOUTH STINGING Trinidad Scorpion peppers and the WORLDS HOTTEST PEPPER, Carolina Reaper Peppers and garlic provide a wonderful flavor for those who want to add flavor as well as heat to anything!\n- PERFECTLY BALANCED with a rich garlic flavor and 50% super hot peppers, Elijah’s Xtreme - Xtreme Regret Hot Pepper Sauce is the hottest, most flavorful hot sauce available. We use only the highest quality ingredients and processes for consistent potency\n- HANDCRAFTED father-and-son recipe gives your own chili, barbecued ribs and chicken wings a fiery, sweat-inducing kick and mouth watering sting. Fat-free, gluten-free and vegan-friendly for all your family and friends\n",
			heatLevel: "Hot",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "1GbtrrFERMJ3gg11kCGs5w",
						type: "Asset",
						createdAt: "2022-08-09T18:47:13.246Z",
						updatedAt: "2022-08-09T18:47:13.246Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Elijah's Xtreme Regret Hot Sauce",
						description: "",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/1GbtrrFERMJ3gg11kCGs5w/bb8455b20c0c45f6708cb77743784a8b/81FNXXQ9UFL._SX679_.jpeg",
							details: {
								size: 24640,
								image: {
									width: 679,
									height: 679
								}
							},
							fileName: "81FNXXQ9UFL._SX679_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	},
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "76sSqhi2XTMQy6UOkOiiqU",
			type: "Entry",
			createdAt: "2022-08-09T18:43:45.106Z",
			updatedAt: "2022-08-09T18:43:45.106Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Crystal Louisiana's Pure Hot Sauce",
			summary: "Original, 12 Ounce Glass Bottle ",
			price: 699,
			description: "Original Crystal Hot Sauce: A Louisiana favorite, this classic hot sauce is made with fresh ground aged cayenne peppers; with medium heat level which keeps the accent on flavor; Use it to season everything ",
			heatLevel: "Medium",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "Jnnw6YaxgQqxky0lwbdzt",
						type: "Asset",
						createdAt: "2022-08-09T18:43:38.708Z",
						updatedAt: "2022-08-09T18:43:38.708Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Crystal Louisiana's Pure Hot Sauce",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/Jnnw6YaxgQqxky0lwbdzt/0d25e3bf87e01a8c6c61db8b619591be/71ads9UuwTS._SY879_.jpeg",
							details: {
								size: 45270,
								image: {
									width: 293,
									height: 879
								}
							},
							fileName: "71ads9UuwTS._SY879_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	},
	{
		metadata: {
			tags: [
			]
		},
		sys: {
			space: {
				sys: {
					type: "Link",
					linkType: "Space",
					id: "v7fvzlkum53d"
				}
			},
			id: "7spzDDm7qo0q23uEVwoTs8",
			type: "Entry",
			createdAt: "2022-08-09T18:41:47.506Z",
			updatedAt: "2022-08-09T18:41:47.506Z",
			environment: {
				sys: {
					id: "master",
					type: "Link",
					linkType: "Environment"
				}
			},
			revision: 1,
			contentType: {
				sys: {
					type: "Link",
					linkType: "ContentType",
					id: "product"
				}
			},
			locale: "en-US"
		},
		fields: {
			name: "Rocky's Bacon Hot Sauce ",
			summary: "Gourmet Red Chili Sauce with Perfectly Balanced Heat – Great Hot Sauce Gift and Wing Sauce - 5 oz ",
			price: 1199,
			description: "ADDS AMAZING FLAVOR WITH HEAT - This sauce has a “bacony” flavor that will have you reminiscing about mornings gone by with friends and family around the kitchen table. You NEED this sauce for your breakfast favorites, of course, but it is also perfect for Mac ‘n’ Cheese, or to bring your wings to the next level! ",
			heatLevel: "Medium",
			image: [
				{
					metadata: {
						tags: [
						]
					},
					sys: {
						space: {
							sys: {
								type: "Link",
								linkType: "Space",
								id: "v7fvzlkum53d"
							}
						},
						id: "19PLDFZMM57HjJroEJZzxy",
						type: "Asset",
						createdAt: "2022-08-09T18:41:37.330Z",
						updatedAt: "2022-08-09T18:41:37.330Z",
						environment: {
							sys: {
								id: "master",
								type: "Link",
								linkType: "Environment"
							}
						},
						revision: 1,
						locale: "en-US"
					},
					fields: {
						title: "Rocky's Bacon Hot Sauce",
						description: "",
						file: {
							url: "//images.ctfassets.net/v7fvzlkum53d/19PLDFZMM57HjJroEJZzxy/bddcb420fea7fdd051a8bb38100ead0e/718MlM9XOeL._SX679_.jpeg",
							details: {
								size: 48366,
								image: {
									width: 679,
									height: 679
								}
							},
							fileName: "718MlM9XOeL._SX679_.jpeg",
							contentType: "image/jpeg"
						}
					}
				}
			]
		}
	}
];

const products = defineEventHandler((event) => {
  return products$2;
});

const products$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  'default': products
});

const cart_post = defineEventHandler(async (event) => {
  const body = await useBody(event);
  const stripeSecret = useRuntimeConfig().stripeSecret;
  const stripe = new Stripe(stripeSecret);
  const res = await stripe.products.list({
    ids: body.products.map((product) => product.id)
  });
  const lineItems = res.data.map((product) => ({
    price: product.default_price,
    quantity: body.products.find((item) => item.id === product.id).quantity
  }));
  const session = await stripe.checkout.sessions.create({
    cancel_url: "http://localhost:3000/cart",
    success_url: "http://localhost:3000/checkout/success",
    mode: "payment",
    line_items: lineItems
  });
  return session;
});

const cart_post$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  'default': cart_post
});

function buildAssetsURL(...path) {
  return joinURL(publicAssetsURL(), useRuntimeConfig().app.buildAssetsDir, ...path);
}
function publicAssetsURL(...path) {
  const publicBase = useRuntimeConfig().app.cdnURL || useRuntimeConfig().app.baseURL;
  return path.length ? joinURL(publicBase, ...path) : publicBase;
}

const getClientManifest = () => import('file://E:/pending_project/vuejs-forge-episode-2-the-project/.nuxt/dist/server/client.manifest.mjs').then((r) => r.default || r).then((r) => typeof r === "function" ? r() : r);
const getServerEntry = () => import('file://E:/pending_project/vuejs-forge-episode-2-the-project/.nuxt/dist/server/server.mjs').then((r) => r.default || r);
const getSSRRenderer = lazyCachedFunction(async () => {
  const clientManifest = await getClientManifest();
  if (!clientManifest) {
    throw new Error("client.manifest is not available");
  }
  const createSSRApp = await getServerEntry();
  if (!createSSRApp) {
    throw new Error("Server bundle is not available");
  }
  const renderer = createRenderer(createSSRApp, {
    clientManifest,
    renderToString: renderToString$1,
    publicPath: buildAssetsURL()
  });
  async function renderToString$1(input, context) {
    const html = await renderToString(input, context);
    if (process.env.NUXT_VITE_NODE_OPTIONS) {
      renderer.rendererContext.updateManifest(await getClientManifest());
    }
    return `<div id="__nuxt">${html}</div>`;
  }
  return renderer;
});
const getSPARenderer = lazyCachedFunction(async () => {
  const clientManifest = await getClientManifest();
  const renderToString = (ssrContext) => {
    const config = useRuntimeConfig();
    ssrContext.payload = {
      serverRendered: false,
      config: {
        public: config.public,
        app: config.app
      }
    };
    let entryFiles = Object.values(clientManifest).filter((fileValue) => fileValue.isEntry);
    if ("all" in clientManifest && "initial" in clientManifest) {
      entryFiles = clientManifest.initial.map((file) => ({ file }));
    }
    return Promise.resolve({
      html: '<div id="__nuxt"></div>',
      renderResourceHints: () => "",
      renderStyles: () => entryFiles.flatMap(({ css }) => css).filter((css) => css != null).map((file) => `<link rel="stylesheet" href="${buildAssetsURL(file)}">`).join(""),
      renderScripts: () => entryFiles.map(({ file }) => {
        const isMJS = !file.endsWith(".js");
        return `<script ${isMJS ? 'type="module"' : ""} src="${buildAssetsURL(file)}"><\/script>`;
      }).join("")
    });
  };
  return { renderToString };
});
const renderer = eventHandler(async (event) => {
  const ssrError = event.req.url?.startsWith("/__nuxt_error") ? useQuery(event) : null;
  const url = ssrError?.url || event.req.url;
  const ssrContext = {
    url,
    event,
    req: event.req,
    res: event.res,
    runtimeConfig: useRuntimeConfig(),
    noSSR: !!event.req.headers["x-nuxt-no-ssr"],
    error: ssrError,
    nuxt: void 0,
    payload: void 0
  };
  const renderer = ssrContext.noSSR ? await getSPARenderer() : await getSSRRenderer();
  const rendered = await renderer.renderToString(ssrContext).catch((e) => {
    if (!ssrError) {
      throw e;
    }
  });
  if (!rendered) {
    return;
  }
  if (event.res.writableEnded) {
    return;
  }
  if (ssrContext.error && !ssrError) {
    throw ssrContext.error;
  }
  if (ssrContext.nuxt?.hooks) {
    await ssrContext.nuxt.hooks.callHook("app:rendered");
  }
  const html = await renderHTML(ssrContext.payload, rendered, ssrContext);
  event.res.setHeader("Content-Type", "text/html;charset=UTF-8");
  return html;
});
async function renderHTML(payload, rendered, ssrContext) {
  const state = `<script>window.__NUXT__=${devalue(payload)}<\/script>`;
  rendered.meta = rendered.meta || {};
  if (ssrContext.renderMeta) {
    Object.assign(rendered.meta, await ssrContext.renderMeta());
  }
  return htmlTemplate({
    HTML_ATTRS: rendered.meta.htmlAttrs || "",
    HEAD_ATTRS: rendered.meta.headAttrs || "",
    HEAD: (rendered.meta.headTags || "") + rendered.renderResourceHints() + rendered.renderStyles() + (ssrContext.styles || ""),
    BODY_ATTRS: rendered.meta.bodyAttrs || "",
    BODY_PREPEND: ssrContext.teleports?.body || "",
    APP: (rendered.meta.bodyScriptsPrepend || "") + rendered.html + state + rendered.renderScripts() + (rendered.meta.bodyScripts || "")
  });
}
function lazyCachedFunction(fn) {
  let res = null;
  return () => {
    if (res === null) {
      res = fn().catch((err) => {
        res = null;
        throw err;
      });
    }
    return res;
  };
}

const renderer$1 = /*#__PURE__*/Object.freeze({
  __proto__: null,
  'default': renderer
});
//# sourceMappingURL=index.mjs.map
