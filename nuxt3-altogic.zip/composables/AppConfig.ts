export const useAppConfig = () => {
  return {
    siteName: "Awesome Sauce",
  };
};